---
name: seo-geo-article-writer
description: Draft or revise one complete website article from topic research using search intent, credible sources and clear answers for readers, search engines and AI answer tools.
---

# SEO and GEO article writer

Use this skill when a user asks for an article, chooses an idea from a shortlist, or requests research followed by a draft. Respect an explicit research-only request. Use the selected topic and the research already in the session. Website Topic Scout handles keyword lookups, so use its exact results and preserve its lookup limits.

## Choose a useful angle

- Identify the reader, the question they want answered, and what they should be able to do after reading. Match the format to the intent. Use a direct explanation for a definition, ordered steps for a how-to, and clear criteria for a comparison.
- Look for a genuine gap in the site's coverage. If an existing article already answers the same question, prefer improving that page and tell the requester which page to update. If you only saw titles or summaries, treat overlap as uncertain.
- Read the brand's supplied brief or relevant public pages for tone, language and facts. Default to Australian English for an Australian audience. If the reader or market is missing, use what the website makes clear or ask only for details that materially change the article.
- Add something specific the reader can use, such as a worked example, checklist, decision table or practical steps. Label illustrative examples. Attribute first-hand experiences only when the requester supplies them.

## Write the article

1. Use one clear Markdown H1 and open with a direct answer or useful summary in one or two sentences. State who the advice is for and any conditions that change the answer.
2. Use descriptive H2s that answer the reader's likely follow-up questions. Build each section around one question or task. Keep paragraphs short and use lists or tables where they make steps, facts or trade-offs easier to scan.
3. Use the search phrase or a natural variation where it fits. Keep the title and headings descriptive. Link to relevant, verified pages on the site with meaningful link text. If you suggest images, give each informative image a concise description for its alt text.
4. Support factual claims with nearby links to the most relevant sources you can verify. Prefer official documentation, original research and supplied evidence. State dates and scope when they change the answer. If an important fact cannot be checked with the tools and sources you have, use a narrower claim, omit it, or flag it for the editor. Keep hypothetical examples clearly labelled.
5. Give the reader a concrete next step. Include a brand link or call to action only where it helps with that next step.

## Hand over a complete draft

Return the entire article in Markdown, ready for review. After the article, add a separate **Publishing notes** section with a descriptive SEO title, a suggested URL slug, a short meta description, and any material facts or link targets that still need verification. Keep keyword metrics and research commentary separate from the article unless the numbers directly help its reader. If you used search metrics in the research, preserve the exact query, market, and availability labels.

Review for search intent, usefulness, source accuracy, natural language, clear headings and overlap with existing pages. For GEO and AEO, make key answers and their supporting evidence easy to locate and understand. Treat rankings, traffic and citations in AI answers as outcomes to measure over time. Return the draft to the requester for approval before any publishing action.

## Reference guidance

- [Google Search Central on helpful, reliable, people-first content](https://developers.google.com/search/docs/fundamentals/creating-helpful-content)
- [Google Search Central SEO starter guide](https://developers.google.com/search/docs/fundamentals/seo-starter-guide)
- [Google Search Central on AI features and websites](https://developers.google.com/search/docs/appearance/ai-features)
- [Bing Webmaster Tools on visibility and citations in AI answers](https://blogs.bing.com/webmaster/2026/2/Introducing-AI-Performance-in-Bing-Webmaster-Tools-Public-Preview/)
